<?php

namespace net\authorize\api\contract\v1;

// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die();
}

/**
 * Class representing MobileDeviceRegistrationResponse
 */
class MobileDeviceRegistrationResponse extends ANetApiResponseType
{


}


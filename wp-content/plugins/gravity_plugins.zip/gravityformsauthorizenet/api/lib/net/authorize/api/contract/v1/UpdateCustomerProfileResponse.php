<?php

namespace net\authorize\api\contract\v1;

// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die();
}

/**
 * Class representing UpdateCustomerProfileResponse
 */
class UpdateCustomerProfileResponse extends ANetApiResponseType
{


}

